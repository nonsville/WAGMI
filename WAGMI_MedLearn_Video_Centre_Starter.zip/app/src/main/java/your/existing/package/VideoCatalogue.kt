package your.existing.package

val sampleLessons = listOf(
    VideoLesson(
        id = "anat-001",
        title = "Introduction to Gross Anatomy",
        subject = "Gross Anatomy",
        topic = "Anatomical terminology",
        youtubeVideoId = "REPLACE_WITH_REAL_VIDEO_ID",
        summary = "Introduction to anatomical study and terminology.",
        notes = """
            Key learning objectives:
            1. Define anatomical position.
            2. Explain anatomical planes.
            3. Distinguish directional terms.
        """.trimIndent(),
        quiz = listOf(
            QuizQuestion(
                question = "Which plane divides the body into right and left portions?",
                options = listOf(
                    "Transverse plane",
                    "Sagittal plane",
                    "Coronal plane",
                    "Oblique plane"
                ),
                correctAnswerIndex = 1,
                explanation = "The sagittal plane divides the body into right and left portions."
            )
        )
    ),
    VideoLesson(
        id = "phys-001",
        title = "Introduction to Human Physiology",
        subject = "Physiology",
        topic = "Homeostasis",
        youtubeVideoId = "REPLACE_WITH_REAL_VIDEO_ID",
        summary = "An introduction to homeostasis and physiological regulation."
    ),
    VideoLesson(
        id = "biochem-001",
        title = "Introduction to Biochemistry",
        subject = "Biochemistry",
        topic = "Biomolecules",
        youtubeVideoId = "REPLACE_WITH_REAL_VIDEO_ID",
        summary = "An overview of the chemical components of living organisms."
    )
)
