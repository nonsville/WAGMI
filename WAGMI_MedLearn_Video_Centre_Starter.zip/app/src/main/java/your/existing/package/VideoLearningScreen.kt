package your.existing.package

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun VideoLearningScreen(
    lessons: List<VideoLesson> = sampleLessons,
    watchedIds: Set<String> = emptySet(),
    onOpenLesson: (VideoLesson) -> Unit
) {
    var search by remember { mutableStateOf("") }
    var subject by remember { mutableStateOf("All") }

    val subjects = listOf("All") + lessons.map { it.subject }.distinct()

    val filtered = lessons.filter { lesson ->
        val matchesSubject = subject == "All" || lesson.subject == subject
        val query = search.trim()
        val matchesSearch = query.isEmpty() ||
            lesson.title.contains(query, ignoreCase = true) ||
            lesson.topic.contains(query, ignoreCase = true) ||
            lesson.subject.contains(query, ignoreCase = true) ||
            lesson.instructor.contains(query, ignoreCase = true)

        matchesSubject && matchesSearch
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "Video Learning Centre",
            style = MaterialTheme.typography.headlineSmall
        )

        Spacer(Modifier.height(12.dp))

        OutlinedTextField(
            value = search,
            onValueChange = { search = it },
            label = { Text("Search lessons or topics") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        Spacer(Modifier.height(8.dp))

        subjects.forEach { item ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { subject = item }
                    .padding(vertical = 2.dp)
            ) {
                RadioButton(
                    selected = subject == item,
                    onClick = { subject = item }
                )
                Text(
                    text = item,
                    modifier = Modifier.padding(top = 12.dp)
                )
            }
        }

        Text(
            text = "${filtered.size} lessons",
            style = MaterialTheme.typography.labelLarge
        )

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(filtered, key = { it.id }) { lesson ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onOpenLesson(lesson) }
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text(
                            lesson.title,
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text("${lesson.subject} • ${lesson.topic}")

                        if (lesson.id in watchedIds) {
                            Text("✓ Completed")
                        }
                        if (lesson.summary.isNotBlank()) {
                            Spacer(Modifier.height(4.dp))
                            Text(lesson.summary, maxLines = 2)
                        }
                    }
                }
            }
        }
    }
}
