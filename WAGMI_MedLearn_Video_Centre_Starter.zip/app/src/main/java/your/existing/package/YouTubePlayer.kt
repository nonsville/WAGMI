package your.existing.package

import android.annotation.SuppressLint
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun YouTubePlayer(
    videoId: String,
    modifier: Modifier = Modifier
) {
    AndroidView(
        modifier = modifier,
        factory = { context ->
            WebView(context).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                webViewClient = WebViewClient()
                loadUrl(
                    "https://www.youtube.com/embed/" +
                        videoId +
                        "?playsinline=1&rel=0"
                )
            }
        },
        update = { webView ->
            val expectedUrl =
                "https://www.youtube.com/embed/" +
                    videoId +
                    "?playsinline=1&rel=0"

            if (webView.url != expectedUrl) {
                webView.loadUrl(expectedUrl)
            }
        }
    )
}
