package your.existing.package

data class VideoLesson(
    val id: String,
    val title: String,
    val subject: String,
    val topic: String,
    val youtubeVideoId: String,
    val instructor: String = "",
    val summary: String = "",
    val notes: String = "",
    val quiz: List<QuizQuestion> = emptyList()
)

data class QuizQuestion(
    val question: String,
    val options: List<String>,
    val correctAnswerIndex: Int,
    val explanation: String = ""
)
