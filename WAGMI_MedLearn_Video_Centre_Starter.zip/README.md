# WAGMI MedLearn — Video Learning Centre Starter

This is a starter module with Kotlin/Jetpack Compose example files. It is **not a complete Android Studio project** and has not been merged into your existing WAGMI Exam Solver, because the existing project source was not attached.

## Files
- `VideoLesson.kt` — lesson and quiz data models
- `VideoCatalogue.kt` — sample lessons and one sample MCQ
- `YouTubePlayer.kt` — basic embedded YouTube player using WebView
- `VideoLearningScreen.kt` — subject filter, topic search, and lesson list

## Before using
1. Replace `your.existing.package` in every `.kt` file with the actual package declared in your app.
2. Copy the Kotlin files into the corresponding package folder in your project.
3. Ensure your app already has Jetpack Compose Material 3 and Compose UI dependencies.
4. Add this permission to `AndroidManifest.xml` if it is not already present:
   `<uses-permission android:name="android.permission.INTERNET" />`
5. Replace `REPLACE_WITH_REAL_VIDEO_ID` with a real YouTube video ID that permits embedding.
6. Connect `VideoLearningScreen` to your existing navigation and CBT/storage systems.

## Important limitations
- This starter does not persist watched progress yet; `watchedIds` is supplied by the caller.
- It does not automatically create summaries or fetch YouTube playlists.
- It does not include a backend, Gemini API, YouTube Data API key, or user authentication.
- Some YouTube videos disallow embedding. Add an "Open in YouTube" fallback in the full app.
- Test playback on a real Android device. WebView playback can vary by device and YouTube policy.

## Recommended next step
Upload your existing WAGMI Exam Solver project ZIP so the files can be adapted to your real package, dependencies, navigation, and existing CBT/database models without overwriting working features.
